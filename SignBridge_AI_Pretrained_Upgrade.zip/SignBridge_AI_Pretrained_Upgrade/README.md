# SignBridge AI — Pretrained Model Integration Prototype

This is a modification of the existing Streamlit SignBridge AI project. It removes the custom Random Forest training workflow from the UI and attempts to load a pretrained video model from Hugging Face for inference.

## Important compatibility note

The reference repository documents a Swin3D-S classifier for 76 Indian Sign Language word classes. This integration expects a compatible PyTorch checkpoint in that Hugging Face repository. The actual checkpoint layout could not be verified in this environment. If its weights use a different architecture or packaging, the app displays a compatibility error; follow the source repository's own inference instructions and adapt the loader before treating it as working.

## Requirements
- Windows 10/11
- Python 3.11 recommended
- Internet connection for the first model download
- 8 GB RAM recommended; CPU inference may be slow
- A webcam for image capture; a short video clip for sequence-based recognition

## Install on Windows
1. Extract this ZIP to `C:\SignBridge_AI_Pretrained_Upgrade`.
2. Open Command Prompt in that folder.
3. Create and activate a virtual environment:

   ```bat
   py -3.11 -m venv .venv
   .venv\Scripts\activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

4. Install PyTorch and torchvision as a matched pair using the official selector: https://pytorch.org/get-started/locally/ . For CPU-only setup, choose Windows + Pip + Python + CPU. Check installation:

   ```bat
   python -c "import torch, torchvision; print(torch.__version__, torchvision.__version__)"
   ```

5. Run `streamlit run app.py`.
6. In **Live Recognition**, click **Download / load pretrained model** to download and validate the checkpoint.
7. Open **Test a video**, upload a short clip showing one supported sign, and click **Recognize sign**.

## Included
- SignBridge Streamlit interface
- Pretrained model download attempt via Hugging Face Hub
- Checkpoint compatibility validation (avoids silently using a mostly random model)
- 16-frame video sampling and normalization
- Top-5 class scores and a configurable rejection threshold
- No custom data collection or training workflow

## Limitations
- Vocabulary is limited to 76 ISL word classes from the referenced model, not all signs.
- A class score is not necessarily calibrated confidence; a threshold does not guarantee unknown-sign detection.
- The camera widget captures a snapshot; use a video clip for motion-aware sequence inference. Continuous live streaming is not yet implemented.
- Checkpoint loading and preprocessing must be verified against the actual repository before relying on predictions.
- Do not use for emergency, medical, legal, or other high-stakes communication.

## References
- Source: https://github.com/Uni-Creator/signBridge
- Model: https://huggingface.co/Creator-090/isl-swin3d-model

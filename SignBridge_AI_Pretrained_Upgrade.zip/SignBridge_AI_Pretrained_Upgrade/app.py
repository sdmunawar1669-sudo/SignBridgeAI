import os, tempfile
from pathlib import Path
import cv2
import numpy as np
import streamlit as st
from PIL import Image

APP_DIR = Path(__file__).parent
MODEL_DIR = APP_DIR / "models"
HF_REPO_ID = os.getenv("SIGNBRIDGE_HF_REPO", "Creator-090/isl-swin3d-model")
NUM_FRAMES, CLIP_SIZE = 16, 224
LABELS = ["afternoon","animal","bad","beautiful","big","bird","blind","cat","cheap","clothing","cold","cow","curved","deaf","dog","dress","dry","evening","expensive","famous","fast","female","fish","flat","friday","good","happy","hat","healthy","horse","hot","hour","light","long","loose","loud","minute","monday","month","morning","mouse","narrow","new","night","old","pant","pocket","quiet","sad","saturday","second","shirt","shoes","short","sick","skirt","slow","small","suit","sunday","t_shirt","tall","thursday","time","today","tomorrow","tuesday","ugly","warm","wednesday","week","wet","wide","year","yesterday","young"]

st.set_page_config(page_title="SignBridge AI", page_icon="🤟", layout="wide")
st.markdown("""
<style>.main{background:#f4f7fb}.block-container{padding-top:1.2rem;max-width:1450px}.hero{padding:1.2rem 1.4rem;border-radius:18px;color:white;background:linear-gradient(120deg,#101d35,#2363d9)}.hero h1{margin:0;font-size:2.2rem}.hero p{margin:.45rem 0 0;opacity:.92}</style>
<div class="hero"><h1>🤟 SignBridge AI</h1><p>Pretrained video-based sign recognition · No user training workflow</p></div>
""", unsafe_allow_html=True)
st.warning("This model reference covers a limited Indian Sign Language vocabulary (76 word classes), not all signs or all sign languages. Do not rely on it for emergency or medical communication.")

@st.cache_resource(show_spinner=False)
def load_pretrained_model():
    """Attempt to load a compatible Swin3D-S/76-class checkpoint from Hugging Face."""
    try:
        import torch
        from torchvision.models.video import swin3d_s
        from huggingface_hub import snapshot_download
    except Exception as e:
        return None, f"Missing/incompatible packages: {e}. Install requirements and restart."
    try:
        local_dir = snapshot_download(repo_id=HF_REPO_ID, local_dir=str(MODEL_DIR / "hf_model"))
    except Exception as e:
        return None, f"Could not download model repository {HF_REPO_ID}: {e}. Check internet access and repository availability."
    candidates = [p for p in Path(local_dir).rglob('*') if p.is_file() and p.suffix.lower() in {'.pth','.pt','.bin','.ckpt'}]
    if not candidates:
        return None, f"Downloaded repository but found no PyTorch checkpoint file in {local_dir}. The repository may require a different inference setup."
    candidates.sort(key=lambda p: (0 if any(s in p.name.lower() for s in ('best','model','weight','checkpoint')) else 1, -p.stat().st_size))
    errors = []
    for checkpoint in candidates:
        try:
            payload = torch.load(checkpoint, map_location='cpu', weights_only=False)
            state = payload
            if isinstance(payload, dict):
                for key in ('state_dict','model_state_dict','model','weights'):
                    if key in payload and isinstance(payload[key], dict):
                        state = payload[key]; break
            if not isinstance(state, dict):
                errors.append(f'{checkpoint.name}: no state dictionary'); continue
            cleaned = {}
            for k,v in state.items():
                if not hasattr(v, 'shape'): continue
                name = k
                for prefix in ('module.','model.','net.'):
                    if name.startswith(prefix): name = name[len(prefix):]
                cleaned[name] = v
            model = swin3d_s(weights=None, num_classes=len(LABELS))
            incompatible = model.load_state_dict(cleaned, strict=False)
            total = len(model.state_dict())
            loaded = total - len(incompatible.missing_keys)
            if loaded < max(10, int(total * 0.75)):
                errors.append(f'{checkpoint.name}: only {loaded}/{total} tensors matched'); continue
            if any('head' in k for k in incompatible.missing_keys):
                errors.append(f'{checkpoint.name}: trained classification head was not loaded'); continue
            model.eval()
            return (model, torch), f"Loaded compatible checkpoint: {checkpoint.name}"
        except Exception as e:
            errors.append(f'{checkpoint.name}: {e}')
    return None, "No checkpoint matched the expected Swin3D-S/76-class architecture. " + " | ".join(errors[:3])

def read_video_frames(video_bytes, suffix='.mp4'):
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
        f.write(video_bytes); name = f.name
    frames = []
    cap = cv2.VideoCapture(name)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total > 0:
        for idx in np.linspace(0, total-1, NUM_FRAMES).astype(int):
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx)); ok, frame = cap.read()
            if ok: frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    cap.release()
    try: os.remove(name)
    except OSError: pass
    if not frames: return None
    while len(frames) < NUM_FRAMES: frames.append(frames[-1].copy())
    return frames[:NUM_FRAMES]

def preprocess_frames(frames, torch):
    from torchvision.transforms import functional as TF
    tensors = []
    for frame in frames:
        image = Image.fromarray(frame).convert('RGB')
        w,h = image.size; scale = 256/min(w,h)
        image = image.resize((int(round(w*scale)), int(round(h*scale))))
        left = (image.width-CLIP_SIZE)//2; top = (image.height-CLIP_SIZE)//2
        image = image.crop((left,top,left+CLIP_SIZE,top+CLIP_SIZE))
        t = TF.to_tensor(image)
        t = TF.normalize(t, mean=[0.43216,0.394666,0.37645], std=[0.22803,0.22145,0.216989])
        tensors.append(t)
    return torch.stack(tensors, dim=1).unsqueeze(0)  # B,C,T,H,W

def predict(frames, loaded):
    (model, torch), status = loaded
    x = preprocess_frames(frames, torch)
    with torch.no_grad(): probs = torch.softmax(model(x), dim=1)[0].cpu().numpy()
    i = int(np.argmax(probs))
    top = sorted([(LABELS[j],float(p)) for j,p in enumerate(probs)], key=lambda z:z[1], reverse=True)[:5]
    return LABELS[i], float(probs[i]), top

with st.sidebar:
    st.header('Navigation')
    page = st.radio('Open section', ['Live Recognition','Test a video','About the model'])
    st.divider(); st.caption('Pretrained inference mode · No custom training page')

if page == 'Live Recognition':
    st.subheader('Camera recognition')
    st.write('The camera widget captures a still image. This video model needs a sequence of frames, so use **Test a video** for motion-aware inference. Continuous live streaming is a later integration step.')
    camera = st.camera_input('Capture a sign')
    if camera:
        st.image(camera, caption='Captured camera image', use_container_width=True)
        st.info('A single image cannot reliably represent motion-based signs. Record a short clip and test it on the Test a video page.')
    st.subheader('Model status')
    if st.button('Download / load pretrained model', type='primary'):
        with st.spinner('Downloading model files and checking checkpoint compatibility…'):
            loaded, msg = load_pretrained_model()
        if loaded: st.success(msg)
        else: st.error(msg)
    else: st.caption('Click to download and validate the pretrained checkpoint. The first download may take time.')

elif page == 'Test a video':
    st.subheader('Recognize a sign from a video clip')
    st.write('Upload a short video containing one sign. The app samples 16 frames. MP4 is recommended.')
    video = st.file_uploader('Upload sign video', type=['mp4','mov','avi','mkv','webm'])
    threshold = st.slider('Minimum score to display a label', 0.10, 0.99, 0.55, 0.01)
    if video:
        frames = read_video_frames(video.getvalue(), suffix='.'+video.name.split('.')[-1])
        if not frames: st.error('Could not read frames from this video. Try an MP4 file.')
        else:
            st.image(frames[0], caption='First sampled frame', use_container_width=True)
            if st.button('Recognize sign', type='primary'):
                with st.spinner('Loading model and analyzing video…'): loaded, msg = load_pretrained_model()
                if not loaded: st.error(msg)
                else:
                    st.caption(msg)
                    try:
                        label, conf, top = predict(frames, loaded)
                        display = label.upper() if conf >= threshold else 'UNKNOWN SIGN'
                        a,b = st.columns(2); a.metric('Prediction', display); b.metric('Model score', f'{conf:.1%}')
                        if display == 'UNKNOWN SIGN': st.info('The highest-scoring class did not reach the threshold. This does not guarantee detection of all unsupported signs.')
                        st.write('Top model classes')
                        st.dataframe([{'Sign':x,'Score':f'{p:.1%}'} for x,p in top], use_container_width=True, hide_index=True)
                        st.caption('Scores may not be calibrated confidence. The model can only output its 76 known classes.')
                    except Exception as e: st.error(f'Inference failed: {e}')
else:
    st.subheader('About this pretrained model')
    st.markdown(f"""**Model repository:** [{HF_REPO_ID}](https://huggingface.co/{HF_REPO_ID})  
**Expected architecture:** torchvision Swin3D-S with a 76-class output head.  
**Expected input:** 16 video frames resized/cropped to 224 × 224.  
**Vocabulary:** 76 Indian Sign Language word classes.  
**No manual training:** the app attempts to download an existing checkpoint and load it for inference.

**Limitations:** This does not recognize all signs or all sign languages. The actual repository may use a different checkpoint format or preprocessing pipeline; if so, the app reports a compatibility error rather than producing a fake prediction. This first version supports sequence inference from uploaded videos; continuous live camera streaming is not yet implemented.""")
    st.markdown('[Open source implementation](https://github.com/Uni-Creator/signBridge)')

st.divider(); st.caption('SignBridge AI · Pretrained model integration prototype · Verify outputs before relying on them')
